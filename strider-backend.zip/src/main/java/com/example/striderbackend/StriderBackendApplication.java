package com.example.striderbackend;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
@SpringBootApplication
public class StriderBackendApplication {
 public static void main(String[] args){SpringApplication.run(StriderBackendApplication.class,args);}
}