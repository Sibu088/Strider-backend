INSERT INTO ACTIVITY (id, title, description, distance_km, duration_minutes, date) VALUES
(RANDOM_UUID(), 'Morning Run', 'Park loop', 5.2, 28, '2025-11-01'),
(RANDOM_UUID(), 'Evening Ride', 'City ride', 12.5, 45, '2025-11-02');
